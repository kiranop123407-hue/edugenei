# EduGenie — Google Gemini Powered Learning Assistant

EduGenie is a lightweight educational assistant based on the supplied project documentation. It provides:

- Question answering
- Beginner-friendly topic explanations
- Exactly 3 MCQs with 4 options each
- Educational passage summarization
- Beginner-to-advanced learning paths

The supplied specification describes FastAPI, HTML/CSS, Gemini for Q&A/quiz/summary/learning paths, and LaMini-Flan-T5 for explanations. The project keeps that architecture while making the model name configurable because Gemini model availability changes over time.

## Project structure

```text
EduGenie/
├── main.py
├── ai_service.py
├── explanation_module.py
├── qna.py
├── quiz_module.py
├── summary_module.py
├── learning_path.py
├── requirements.txt
├── .env.example
├── .gitignore
├── README.md
├── templates/
│   └── index.html
├── static/
│   ├── app.js
│   └── style.css
└── tests/
    └── test_app.py
```

## VS Code setup — Windows

1. Install Python 3.10+ and VS Code.
2. Open the `EduGenie` folder in VS Code.
3. Open **Terminal → New Terminal**.
4. Create a virtual environment:

```powershell
python -m venv .venv
```

5. Activate it:

```powershell
.venv\Scripts\Activate.ps1
```

If PowerShell blocks activation, use Command Prompt and run:

```cmd
.venv\Scripts\activate.bat
```

6. Install dependencies:

```powershell
python -m pip install --upgrade pip
pip install -r requirements.txt
```

## Gemini API key

Create a `.env` file by copying `.env.example` and put your Gemini API key in:

```env
GEMINI_API_KEY=your_key_here
DEMO_MODE=false
```

The Google GenAI Python SDK is used for `generate_content`, with JSON response configuration for the quiz endpoint.

## Run

```powershell
uvicorn main:app --reload
```

Open:

`http://127.0.0.1:8000`

## Test without an API key

For UI and API testing only, set:

```env
DEMO_MODE=true
```

Then run the server. Demo responses prove the frontend/backend wiring without consuming API quota. They are not real AI answers.

Run automated tests:

```powershell
pytest -q
```

## Real LaMini explanation model (optional)

The project documentation assigns concept explanation to `LaMini-Flan-T5-783M`. To use it locally, uncomment `transformers` and `torch` in `requirements.txt`, install them, and set:

```env
USE_LOCAL_EXPLAINER=true
LOCAL_EXPLAINER_MODEL=MBZUAI/LaMini-Flan-T5-783M
```

The first run downloads the model and can require significant disk/RAM. If local loading fails, the explanation module falls back to Gemini.

## API endpoints

- `GET /` — web application
- `GET /health` — health check
- `POST /qa` — `{"question":"..."}`
- `POST /explain` — `{"text":"..."}`
- `POST /quiz` — `{"text":"..."}`
- `POST /summarize` — `{"text":"..."}`
- `POST /learn/recommendations` — `{"text":"..."}`
- `POST /api/task` — frontend unified endpoint

Example:

```powershell
curl.exe -X POST http://127.0.0.1:8000/qa -H "Content-Type: application/json" -d "{\"question\":\"Which is the largest ocean?\"}"
```

## Testing checklist

1. Open the home page.
2. Select **Ask a Question** and ask `Which is the largest ocean?`.
3. Select **Explain a Topic** and enter `Pythagoras theorem`.
4. Select **Generate Quiz** and paste a short lesson. Confirm exactly 3 questions and 4 options per question.
5. Select **Summarize Text** and paste a paragraph.
6. Select **Learning Path** and enter `SQL`.
7. Run `pytest -q`.

## Notes on the supplied documentation

The original specification names Gemini 1.5 Pro. This implementation does not hard-code that retired/changed model identifier; `GEMINI_MODEL` controls the model so the project can be kept runnable as Google changes available models. The official current Google GenAI SDK uses `from google import genai` and `client.models.generate_content(...)`.
