import json
import os
import re
from typing import Any

from dotenv import load_dotenv

load_dotenv()

try:
    from google import genai
    from google.genai import types
except ImportError:  # pragma: no cover
    genai = None
    types = None


class AIService:
    """Small wrapper around Google's current GenAI Python SDK.

    The PDF describes Gemini 1.5 Pro. The model is configurable so the project can
    use an available Gemini model without changing application code.
    """

    def __init__(self) -> None:
        self.api_key = os.getenv("GEMINI_API_KEY", "").strip()
        self.model = os.getenv("GEMINI_MODEL", "gemini-2.5-flash")
        self.demo_mode = os.getenv("DEMO_MODE", "false").lower() == "true"
        self._client = None
        if self.api_key and genai is not None:
            self._client = genai.Client(api_key=self.api_key)

    @property
    def available(self) -> bool:
        return self._client is not None

    def generate(self, prompt: str, *, temperature: float = 0.4, max_tokens: int = 1200) -> str:
        if self._client is None:
            if self.demo_mode:
                return self._demo(prompt)
            raise RuntimeError("Gemini is not configured. Set GEMINI_API_KEY in .env, or enable DEMO_MODE=true for local testing.")

        response = self._client.models.generate_content(
            model=self.model,
            contents=prompt,
            config=types.GenerateContentConfig(
                temperature=temperature,
                max_output_tokens=max_tokens,
            ),
        )
        text = getattr(response, "text", None)
        if not text:
            raise RuntimeError("Gemini returned an empty response.")
        return text.strip()

    def generate_json(self, prompt: str, schema: dict[str, Any], *, temperature: float = 0.3) -> dict[str, Any]:
        if self._client is None:
            if self.demo_mode:
                return self._demo_json(prompt)
            raise RuntimeError("Gemini is not configured. Set GEMINI_API_KEY in .env, or enable DEMO_MODE=true for local testing.")

        response = self._client.models.generate_content(
            model=self.model,
            contents=prompt,
            config=types.GenerateContentConfig(
                temperature=temperature,
                response_mime_type="application/json",
                response_schema=schema,
            ),
        )
        text = getattr(response, "text", None)
        if not text:
            raise RuntimeError("Gemini returned an empty JSON response.")
        try:
            return json.loads(text)
        except json.JSONDecodeError as exc:
            raise RuntimeError(f"Gemini returned invalid JSON: {exc}") from exc

    @staticmethod
    def _demo(prompt: str) -> str:
        lower = prompt.lower()
        if "summar" in lower:
            return "Demo summary: The supplied passage has been condensed into its main ideas for quick revision."
        if "learning path" in lower or "recommend" in lower:
            return "Demo learning path: Start with fundamentals, practice core concepts, build a small project, then progress to advanced topics."
        if "explain" in lower:
            return "Demo explanation: This topic is explained in simple language. Learn the definition first, then understand the key steps and practise with examples."
        return "Demo answer: This is a local demonstration response. Configure GEMINI_API_KEY for real Gemini-generated answers."

    @staticmethod
    def _demo_json(prompt: str) -> dict[str, Any]:
        if "quiz" in prompt.lower():
            return {
                "questions": [
                    {"question": "What is the main idea of the supplied topic?", "options": ["A core concept", "An unrelated fact", "A random example", "None"], "correct_answer": "A core concept"},
                    {"question": "Which approach best supports learning?", "options": ["Practice", "Avoid examples", "Skip fundamentals", "Memorize without understanding"], "correct_answer": "Practice"},
                    {"question": "What should a learner do after learning the basics?", "options": ["Apply them", "Stop learning", "Ignore feedback", "Delete notes"], "correct_answer": "Apply them"},
                ]
            }
        return {"answer": "Demo structured response."}


ai = AIService()


def clean_json_block(value: str) -> str:
    value = value.strip()
    value = re.sub(r"^```(?:json)?\s*", "", value, flags=re.I)
    value = re.sub(r"\s*```$", "", value)
    return value.strip()
