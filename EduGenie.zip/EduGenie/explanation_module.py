import os

from ai_service import ai

_local_pipeline = None
_local_error = None


def _load_local_model():
    global _local_pipeline, _local_error
    if _local_pipeline is not None:
        return _local_pipeline
    try:
        from transformers import pipeline
        model_name = os.getenv("LOCAL_EXPLAINER_MODEL", "MBZUAI/LaMini-Flan-T5-783M")
        _local_pipeline = pipeline("text2text-generation", model=model_name, device=-1)
        return _local_pipeline
    except Exception as exc:  # local model is optional because it is large
        _local_error = exc
        return None


def explain_topic(topic: str) -> str:
    use_local = os.getenv("USE_LOCAL_EXPLAINER", "false").lower() == "true"
    if use_local:
        model = _load_local_model()
        if model is not None:
            result = model(f"Explain this educational topic simply for a beginner: {topic}", max_new_tokens=220, do_sample=False)
            return result[0]["generated_text"].strip()
    prompt = f"""Explain the following educational topic to a beginner.
Use simple language, a short definition, 3-5 key points, and one easy example.
Topic: {topic}
"""
    return ai.generate(prompt, temperature=0.25, max_tokens=900)
