from ai_service import ai


def get_learning_recommendations(topic: str) -> str:
    prompt = f"""Create a personalized learning path for the topic below.
Organize it from beginner to advanced. Include difficulty, suggested timeline, what to learn,
practice ideas, and resource types such as videos, articles, documentation, or books.
Keep the plan practical for a student and explain prerequisites where needed.

Topic: {topic}
"""
    return ai.generate(prompt, temperature=0.35, max_tokens=1500)
