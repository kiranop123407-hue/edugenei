from ai_service import ai


def answer_question(question: str) -> str:
    prompt = f"""You are EduGenie, a student-friendly educational assistant.
Answer the question accurately and concisely. Explain unfamiliar terms briefly.
If the question is ambiguous, state the assumption you made.

Question:
{question}
"""
    return ai.generate(prompt, temperature=0.25, max_tokens=900)
