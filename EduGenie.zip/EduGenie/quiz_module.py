from ai_service import ai

QUIZ_SCHEMA = {
    "type": "object",
    "properties": {
        "questions": {
            "type": "array",
            "minItems": 3,
            "maxItems": 3,
            "items": {
                "type": "object",
                "properties": {
                    "question": {"type": "string"},
                    "options": {"type": "array", "items": {"type": "string"}, "minItems": 4, "maxItems": 4},
                    "correct_answer": {"type": "string"},
                },
                "required": ["question", "options", "correct_answer"],
            },
        }
    },
    "required": ["questions"],
}


def generate_quiz(passage: str) -> list[dict]:
    prompt = f"""Create exactly 3 multiple-choice questions from this educational passage.
Each question must have exactly 4 options. The correct_answer must exactly match one option.
Avoid trick questions and keep questions relevant to the passage.

Passage:
{passage}
"""
    data = ai.generate_json(prompt, QUIZ_SCHEMA, temperature=0.25)
    questions = data.get("questions")
    if not isinstance(questions, list) or len(questions) != 3:
        raise ValueError("Quiz must contain exactly 3 questions.")
    for item in questions:
        if len(item.get("options", [])) != 4:
            raise ValueError("Every quiz question must contain exactly 4 options.")
        if item.get("correct_answer") not in item["options"]:
            raise ValueError("correct_answer must match one of the options.")
    return questions
