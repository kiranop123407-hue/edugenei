const task = document.getElementById('task');
const input = document.getElementById('inputText');
const button = document.getElementById('submitBtn');
const result = document.getElementById('result');
const status = document.getElementById('status');
const copyBtn = document.getElementById('copyBtn');
let lastText = '';

const placeholders = {
  qa: 'Example: Which is the largest ocean?',
  explain: 'Example: Explain the Pythagoras theorem simply.',
  quiz: 'Paste a lesson, topic, or passage to generate 3 MCQs.',
  summarize: 'Paste the educational passage you want summarized.',
  recommend: 'Example: SQL for a beginner who wants to become job-ready.'
};

task.addEventListener('change', () => { input.placeholder = placeholders[task.value]; });

function escapeHtml(value) {
  return value.replace(/[&<>'"]/g, c => ({'&':'&amp;','<':'&lt;','>':'&gt;',"'":'&#39;','"':'&quot;'}[c]));
}

function renderQuiz(questions) {
  return questions.map((q, i) => `
    <div class="quiz-q">
      <strong>${i + 1}. ${escapeHtml(q.question)}</strong>
      ${q.options.map((opt, j) => `<label><input type="radio" name="q${i}" value="${escapeHtml(opt)}"> ${String.fromCharCode(65+j)}. ${escapeHtml(opt)}</label>`).join('')}
    </div>`).join('');
}

button.addEventListener('click', async () => {
  const text = input.value.trim();
  if (!text) { result.innerHTML = '<span class="error">Please enter some text.</span>'; return; }
  button.disabled = true; copyBtn.disabled = true; status.textContent = 'Generating…'; result.className = 'result muted'; result.textContent = 'Working on it…';
  try {
    const res = await fetch('/api/task', { method:'POST', headers:{'Content-Type':'application/json'}, body: JSON.stringify({task:task.value, text}) });
    const data = await res.json();
    if (!res.ok) throw new Error(data.detail || 'Request failed');
    if (task.value === 'quiz') result.innerHTML = renderQuiz(data.quiz);
    else result.textContent = data.answer || data.explanation || data.summary || data.recommendations;
    result.className = 'result';
    lastText = result.innerText;
    copyBtn.disabled = false; status.textContent = 'Done';
  } catch (err) {
    result.className = 'result error'; result.textContent = err.message; status.textContent = 'Error';
  } finally { button.disabled = false; }
});

copyBtn.addEventListener('click', async () => {
  if (!lastText) return;
  await navigator.clipboard.writeText(lastText);
  status.textContent = 'Copied';
  setTimeout(() => status.textContent = 'Ready', 1200);
});
