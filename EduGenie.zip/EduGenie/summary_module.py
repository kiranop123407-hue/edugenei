from ai_service import ai


def summarize_text(text: str) -> str:
    prompt = f"""Summarize the following educational passage for quick revision.
Keep the essential facts and concepts, remove repetition, and use clear bullet points when useful.
Do not add facts that are not supported by the passage.

Passage:
{text}
"""
    return ai.generate(prompt, temperature=0.2, max_tokens=1100)
