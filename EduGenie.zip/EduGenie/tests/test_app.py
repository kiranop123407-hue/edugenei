import os

os.environ["DEMO_MODE"] = "true"
os.environ.pop("GEMINI_API_KEY", None)

from fastapi.testclient import TestClient
from main import app

client = TestClient(app)


def test_health():
    response = client.get("/health")
    assert response.status_code == 200
    assert response.json()["status"] == "ok"


def test_home():
    response = client.get("/")
    assert response.status_code == 200
    assert "EduGenie" in response.text


def test_qa_demo():
    response = client.post("/qa", json={"question": "What is Python?"})
    assert response.status_code == 200
    assert "answer" in response.json()


def test_explain_demo():
    response = client.post("/explain", json={"text": "Photosynthesis"})
    assert response.status_code == 200
    assert "explanation" in response.json()


def test_quiz_demo():
    response = client.post("/quiz", json={"text": "Python is a programming language."})
    assert response.status_code == 200
    quiz = response.json()["quiz"]
    assert len(quiz) == 3
    assert all(len(q["options"]) == 4 for q in quiz)


def test_summary_demo():
    response = client.post("/summarize", json={"text": "A long educational passage."})
    assert response.status_code == 200
    assert "summary" in response.json()


def test_learning_path_demo():
    response = client.post("/learn/recommendations", json={"text": "SQL"})
    assert response.status_code == 200
    assert "recommendations" in response.json()
